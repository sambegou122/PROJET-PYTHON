-----------------
tp-arbresbinaires
-----------------

~~~~~~~~~~
Etat du TP
~~~~~~~~~~

Décrivez ici l'état d'avancement du TP.

~~~~~~~~~~~~~~~~~~~~~~
Réponses aux questions
~~~~~~~~~~~~~~~~~~~~~~

Toutes les fonctions à réaliser ont bien été implanté pour ce TP.
Nous avons ajouté la fonction nbComp.

Question 5.2.4
--------------

Nous avons implémenté la fonction testNbAbres. Pour calculer le nombre d'arbre possible pour n allant de 0 à 19.

Question 5.2.5
--------------

Le calcul est long car on a des appelles qui se répetent beaucoup


Question 5.3.1
--------------



Question 5.3.2
--------------

On vérifie que la valeurs à gauche d'un noeud est inférieur et pour celui de droite supérieur.

Question 5.3.7
--------------

Pour l'arbre 3 il est logique qu'il y est moins de comparaisons car 0 étant la plus petite valeur il suffit de vérifier à chaque fois à gauche et vu que pour l'arbre la hauteur du noeud le plus à gauche est de 2.

Question 5.3.8
--------------

Pour la plus petite valeur on se dirige vers le plus à gauche. Pour la plus grande on se dirige le plus à droite.

Question 5.4.2
--------------

Pour la réalisation de la fonction jouer() on a fait en sorte que nous indiquons à l'ordinateur si le chiffre qu'il nous donne est trop grand ou trop petit voir c'est celui recherché.
(On en a parlé avec vous).