============================
:mod:`hash_functions` module
============================

.. autoclass:: hash_functions.HashFunctions
   :members:
      
   .. automethod:: __init__		

