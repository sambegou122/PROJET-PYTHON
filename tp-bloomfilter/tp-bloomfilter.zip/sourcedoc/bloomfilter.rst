=========================
:mod:`bloomfilter` module
=========================

.. autoclass:: bloomfilter.BloomFilter
   :members:
      
   .. automethod:: __init__		
		  

